//
// L22S02 - Shorter way
//
var list = [1, 3, 5];
gs.info('length of list is: ' + list.length);
//
// L31S02 - Use the position of a character/substring as a condition
//
var short_description = 'System is displaying error message';
if (short_description.indexOf('error') >= 0) {
  gs.info("Error message found");
}
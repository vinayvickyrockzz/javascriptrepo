//
// L20S01 - bad script w/o try/catch
//

for (var i = 0; i < 5; i++) {
  gs.info('i=' + i + ' answer=' + answer);
}
gs.info('done');
//
// L01S01 - first script
//
gs.info('Hello, world!');
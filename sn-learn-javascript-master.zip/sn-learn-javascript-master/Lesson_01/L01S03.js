//
// L01S03 - example client side script
//
function onLoad() {

  alert('Current state value is: ' + g_form.getValue('state'));

}
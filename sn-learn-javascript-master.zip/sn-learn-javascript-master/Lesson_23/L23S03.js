//
// L23S03 - What else can you get..
//
var list = ['apple', 'banana', 'orange'];

list.forEach(function (item, index, arr) {
  gs.info('embedded function item=' + item + ' index=' + index + ' arr=' + arr);
});

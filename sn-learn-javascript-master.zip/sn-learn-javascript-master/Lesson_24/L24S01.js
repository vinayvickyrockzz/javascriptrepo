//
//  L24S01 - Common array methods/functions
//
var list = ['Chuck', 'Kreg', 'Stacey'];
gs.info('list=' + list);

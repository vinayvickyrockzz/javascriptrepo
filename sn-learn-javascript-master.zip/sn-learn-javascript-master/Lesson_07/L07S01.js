// 
// L07S01 - Special characters
//
// \n = new line
// \t = tab
// \\ = backslash
// \' = single quote
// \" = double quote
//
gs.info('Single string\nTwo lines');
gs.info('Chuck\'s simple script');
gs.info('Don\'t confuse a forward slash (/) with a backslash(\\)');
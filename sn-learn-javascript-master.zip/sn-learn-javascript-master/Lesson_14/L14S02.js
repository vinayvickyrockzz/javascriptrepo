//
// L14S02 - Truthy and Falsy
//

// What about numbers
//
var num = 0; // <== try with different numbers
gs.info(num + ' is ' + ((num) ? 'true' : 'false'));

//
// L19S01 - Functions
//
function sayHello() {
  gs.info('Hello');
}
sayHello();
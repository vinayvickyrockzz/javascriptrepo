//
// Lab 2
//
// What is 3 + 2 * 5?
//
gs.info(3 + 2 * 5); // 13